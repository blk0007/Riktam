<?php

namespace App\Http\Controllers;
/*use App\Models\Webuser;
use App\Models\Passwordreset;
use App\Models\Usergroup;
use App\Models\Userprofile;
use Hash;
use Auth;
use Mail;
use File;
use DB;
use URL;
use Session;
use Carbon\Carbon;
use Validator;
use Image;*/

use Illuminate\Http\Request;
use Auth;


class UserController extends Controller {

    /*public function __construct() {

    }*/

    public function index() {

       // dd('dddddd');
        if(Auth::user()){
            return redirect('/');
        }
        return view('auth.login');
    }

    public function userlogin()
    {

        dd('dd');


       // dd(auth());

        $email = request()->get('email');

        $password = request()->get('password');

        //dd($email);
        //dd($password);

        //dd(['email' => $email, 'password' => $password]);

        //dd(auth()->attempt(['email' => $email, 'password' => $password]));

        if(auth()->attempt(['email' => $email, 'password' => $password]))

        {
            flash()->info('Welcome back, '.auth()->user()->name.'!');

            logger('Successful User login with email: '.$email);
            request()->session()->flash('alert-success', 'Welcome back, '.auth()->user()->name.'!');
            if(request()->returnurl)
            {
                $returnurl = base64_decode(request()->returnurl);
                return redirect($returnurl);
            }
            return redirect('/');
        }

        logger('Failed admin login attempt with email: '.$email);

        dd('Failed admin login attempt with email: '.$email);
        flash()->error('Invalid Credentials!');

        return redirect()->back()->withInput();
    }
}

