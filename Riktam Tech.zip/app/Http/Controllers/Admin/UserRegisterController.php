<?php

namespace App\Http\Controllers\Admin;

use App\Admin;
use App\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Routing\Controller;

class UserRegisterController extends Controller
{
    public function showRegistrationForm()
    {

        // dd('ddddddd');
        return view('admin.user-register');
    }
    public function showAdminRegistrationForm()
    {
        return view('admin.admin-register');
    }

    public function createUser()
    {
        if (Auth::guard('admin')->check()) {
            $data = request()->all();
            $this->validator($data)->validate();
            $user = $this->create($data);
            if ($user)
                request()->session()->flash('alert-success', 'Welcome back,');
                return redirect('admin/home');
        }
    }

    public function createAdmin()
    {

       // dd('dd');

        if (Auth::guard('admin')->check()) {
            $data = request()->all();

          //  dd($data);

            $this->validator($data)->validate();
            $user = $this->createAdminEntry($data);



            if ($user)
                request()->session()->flash('alert-success', 'Welcome back,');
                return redirect('admin/home');
        }
    }

    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param array $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
    }

    /**
     * @param array $data
     * @return User|\Illuminate\Database\Eloquent\Model
     */
    protected function createAdminEntry(array $data)
    {

        //dd('wwwww');

        return Admin::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
    }
}
