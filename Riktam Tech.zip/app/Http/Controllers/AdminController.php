<?php


namespace App\Http\Controllers;

use App\Models\Users;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        //TODO need to list all users

        $is_admin = false;
        if (Auth::guard('admin')->check()) {
            $is_admin = true;
        }

        $reg_users = Users::orderBy('created_at', 'DESC')->paginate();

        return view('admin.home', compact('is_admin','reg_users'));
    }
    public function deleteUser(Request $request)
    {

        $input_data = $request->all();
        if(!empty($input_data['id']) && Auth::guard('admin')->check()){
            Users::where('id', $input_data['id'])->delete();

            return 'deleted successfully';
        }



        return view('admin.home', compact('is_admin','reg_users'));
    }
}
