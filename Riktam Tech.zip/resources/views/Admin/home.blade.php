@extends('layouts.app')

@section('content'){{--
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Admin Dashboard</div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in as Admin!
                </div>
            </div>
        </div>
    </div>
</div>--}}
<div class="banner static-banner courses-banner center">
    <div class="banner-wrapper">
        <div class="banner-left">
        </div>
        <div class="banner-right">
            <div class="right-container">
<!--                <h2 class="title">Users</h2>-->
            </div>
        </div>
    </div>
</div>
<div class="container container-padding" id="scrollTo">
    <div class="inlingua-section">
        <div class="row">
            <div class="col-sm-1"></div>
            <div class="col-sm-10">
                <div class="courses-card">
                    <table align="center" class="table table-striped">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($reg_users as $each_key => $each_user)
                            <tr>
                                <th>{{++$each_key}}</th>
                                <th>{{$each_user->name}}</th>
                                <td>{{$each_user->name}}</td>
                                <td>
                                    <button type="submit" class="btn">
                                        <a onclick="deleteUser({{$each_user->id}})">
                                            <span class="hidden-xs">Delete</span>
                                        </a>
                                    </button>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-sm-1"></div>
        </div>
    </div>
</div>
<script>
    function padStart(str) {
        return ('0' + str).slice(-2)
    }

    function deleteUser(user_id) {

        console.log('ddddd');
        console.log(user_id);

        $.ajax({
            method: 'post',
            url: "{!!route('admin.user.deleteuser')!!}",
            data: {
                "_token": "{{ csrf_token() }}",
                "id": user_id,
            },
            complete: function (r) {
                console.log(r.responseText);
                console.log(r.responseText == 'deleted successfully');


                if(r.responseText == 'deleted successfully'){
                    location.reload();
                }
            }
        })
    }
</script>
@endsection


